<template>
    <div class="container">
      <div class="row justify-content-center mt-5">
        <div class="col-md-6">
          <div class="card">
            <div class="card-header"><b>Şifremi Unuttum</b></div>
            <div class="card-body">
              <form @submit.prevent="resetPassword">
                <div class="mb-3">
                  <label for="email" class="form-label">E-posta</label>
                  <input type="email" class="form-control" id="email" v-model="email" required>
                </div>
                <button type="submit" class="btn btn-success">Şifre Sıfırlama Linki Gönder</button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </template>
  
  <script>
  import { ref } from 'vue';
  import { getAuth, sendPasswordResetEmail } from "firebase/auth";
  
  export default {
    data() {
      return {
        email: ''
      };
    },
    methods: {
      resetPassword() {
        const auth = getAuth();
        sendPasswordResetEmail(auth, email.value)
          .then(() => {
          // Şifre sıfırlama linki başarıyla gönderildi.
          alert('Şifre sıfırlama linki e-posta adresinize gönderildi.');
          })
          .catch((error) => {
            const errorCode = error.code;
            const errorMessage = error.message;
            alert('Şifre sıfırlama linki gönderilemedi. '+error);
          });
      }
    }
  };
  </script>
  