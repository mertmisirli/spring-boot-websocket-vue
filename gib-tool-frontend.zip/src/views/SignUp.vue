<template>
  <div>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <Toast />
    <!-- Eğer "isSignup" değişkeni fale ise, kayıt formunu göster -->
    <div v-if="!isSignup" class="container signup-part p-5 mb-5 rounded-5 text-center">
      <div class="row mt-5">
        <div class="col-md-4 d-none d-md-flex justify-content-center align-items-center signup-img">
          <img src="../assets/yurtiçikargo.png" class="img-fluid" alt="Yurtiçi Kargo" width="900" height="700">
        </div>

        <!-- Form ile resim arasındaki boşluk -->
        <div class="col-md-2"></div>
        <!-- Kullanıcı bilgilerinin girildiği form alanı -->
        <div class="p-3 col-12 col-md-5 col-xs-10 mt-5 mb-5 user-info rounded-3 d-flex align-items-center justify-content-center" style="height: 500px; width: 400px;">
          <form class="mx-1 mx-md-4" @submit.prevent="SignUp">
          <!-- Kullanıcı bilgileri alanları -->
            <!-- E POSTA -->
            <div class="d-flex flex-row align-items-center mb-4">
              <i class="bi bi-envelope fa-lg me-3 fa-fw"></i>
              <div class="form-outline flex-fill mb-0">
                <input type="email" required placeholder="E-Posta" id="form3Example4c" v-model="email" class="rounded-4 p-3 mt-2 w-100" style="border-color: white;" />
                <label class="form-label" for="form3Example3c"></label>
              </div>
            </div>
            <!-- ŞİFRE -->
            <div class="d-flex flex-row align-items-center mb-4">
              <i class="bi bi-lock fa-lg me-3 fa-fw"></i>
              <div class="form-outline flex-fill mb-0">
                <input
                  required placeholder="Şifre"
                  id="form3Example4c"
                  v-model="password"
                  class="rounded-4 p-3 pl-3 mt-2 w-100"
                  style="border-color: white;"
                  :type="showPassword ? 'text' : 'password'"
                />
                <label class="form-label" for="form3Example4c"></label>
                <!-- Göz ikonu -->
                <i
                  class="bi position-absolute"
                  :class="showPassword ? 'bi-eye' : 'bi-eye-slash'"
                  @click="togglePasswordVisibility"
                  style="cursor: pointer; top: 50%; transform: translateY(-50%); right: 15px;"
                ></i>
              </div>
            </div>

            <!-- ŞİFRE TEKRARI -->
            <div class="d-flex flex-row align-items-center mb-4">
              <i class="bi bi-lock fa-lg me-3 fa-fw"></i>
              <div class="form-outline flex-fill mb-0">
                <input
                  required placeholder="Şifre tekrarı"
                  id="form3Example4cRepeat"
                  v-model="passwordtekrarı"
                  class="rounded-4 p-3 pl-3 mt-2 w-100"
                  style="border-color: white;"
                  :type="showPassword ? 'text' : 'password'"
                />
                <label class="form-label" for="form3Example4cRepeat"></label>
                <!-- Göz ikonu -->
                <i
                  class="bi position-absolute"
                  :class="showPassword ? 'bi-eye' : 'bi-eye-slash'"
                  @click="togglePasswordVisibility"
                  style="cursor: pointer; top: 50%; transform: translateY(-50%); right: 15px;"
                ></i>
              </div>
            </div>

            <div class="d-grid gap-2 mt-5">
              <!-- Kayıt ol butonu -->
              <Button class="rounded-2" type="submit" label="Kayıt Ol" severity="success" id="submit-btn"></Button>
            </div><br><br>

            <div class="text-center">
              <!-- Giriş sayfasına yönlendirme linki -->
              <p class="mesaj">Zaten Üye Misin <router-link style="text-decoration: none; " to="/"><b>Giriş Yap</b></router-link></p>
              <p>Veya</p>
              <a href="https://accounts.google.com/signup/v2/createaccount?continue=https%3A%2F%2Fwww.google.com%2F%3Fptid%3D19027681%26ptt%3D8%26fpts%3D0&biz=false&flowName=GlifWebSignIn&flowEntry=SignUp" target="_blank" class="btn btn-secondary btn-floating mx-1">
                <i class="fab fa-google"></i>
              </a>
              <a href="https://www.github.com" target="_blank" class="btn btn-secondary btn-floating mx-1">
                <i class="fab fa-github"></i>
              </a>
              <a href="https://www.twitter.com" target="_blank" class="btn btn-secondary btn-floating mx-1">
                <i class="fab fa-twitter"></i>
              </a>
            </div>
          </form>
        </div>
      </div>
    </div>

    <!-- Kayıt olma modunda ise bu kısım gösterilecek -->
    <div v-else>
      <div class="position-absolute top-50 start-50 translate-middle w-50" style="max-height: 10%;">
        <img src="../assets/preloader.gif" height="95" width="95">
      </div>
    </div>

    <!-- Hata mesajı gösterme -->
    <div v-if="showError" class="alert alert-danger mt-3">
      Lütfen tüm alanları doldurun.
    </div>
    <div v-if="showEmailError" class="alert alert-danger mt-3">
      Lütfen geçerli bir e-posta adresi girin.
    </div>
    <div v-if="showPasswordError" class="alert alert-danger mt-3">
      Şifreler uyuşmuyor veya geçerli değil.
    </div>

  </div>
</template>

<script setup>
import { ref } from 'vue'
import { getAuth, createUserWithEmailAndPassword } from 'firebase/auth'
import { useRouter } from 'vue-router'

const email = ref('')
const password = ref('')
const passwordtekrarı = ref('')
const showError = ref(false)
const showEmailError = ref(false)

//GÖZ İKONU ÇALIŞSIN DİYE
const showPassword = ref(false);
const showPasswordError = ref(false);

const togglePasswordVisibility = () => {
  showPassword.value = !showPassword.value
}

const router = useRouter() // get a reference to our vue router

const SignUp = (event) => {
  event.preventDefault()

  // Şifrelerin uyup uymadığını kontrol et
  if (password.value === passwordtekrarı.value) {
    alert("Başarılı Kayıt Oldunuz!")
    createUserWithEmailAndPassword(getAuth(), email.value, password.value)
      .then((userCredential) => {
        const user = userCredential.user
        console.log(user)
        console.log("Signup completed")
        router.push('/')
      })
      .catch(error => {
        console.log(error.code)
        alert(error.message)
      })
  } else {
    showError.value = true
    alert("Şifreniz eşleşmedi tekrar deneyiniz!")
  }
}
</script>

<style>
#submit-btn {
height: 45px;
}

.user-info {
background-color: rgba(231, 226, 226, 0.737);
box-shadow: 3px 7px 13px 6px #888888;
height: 450px;
align-items: center;
flex-direction: column;
}

.signup-part {
display: flex;
flex-direction: column;
align-items: center;
font-family: var(--italic);
background-color: rgba(237, 236, 236, 0.851);
margin-top: 50px;
}

/*şifre kutusunun içine göz simgesini ortalamak için */
.form-outline {
position: relative;
}

form div {
margin: -10px;
}

.login-form {
display: flex;
flex-direction: column;
align-items: center;
}

.form label {
width: 120px;
border: white;
}

button {
color: p-button-primary;
background-color: p-button-primary;
}

.vertical-line {
border-left: 0.5px solid black;
height: 600px;
margin: 0 auto;
}

@media only screen and (max-width: 600px) {
body {
  background-color: lightblue;
}

.signup-part img {
  display: none;
}
}
</style> 