<template>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <Toast />
    <div v-if="!isLoading" class="container login-part p-5 mb-5 rounded-5 text-center">
        <div class="row mt-5 d-flex">
            <div class="col-md-4 d-md-flex d-sm-none justify-content-center align-items-center login-img">
                <img src="../assets/yk_logo.png" class="img-fluid" alt="Yurtici Cargo" width="800" height="400">
            </div>

            <div class="col-md-2">

            </div>

            <div class="col-12 col-md-6 mt-5 mb-5 user-info rounded-3  align-items-center justify-content-center"
                style="height: 600px;">
                <form @submit.prevent="login">
                    <!-- E POSTA -->
                    <div class="d-flex align-items-center mb-4">
                        <i class="bi bi-envelope fa-lg me-3 fa-fw"></i>
                        <div class="form-outline  mb-0">
                            <input type="email" required placeholder="E-Posta" id="form3Example4c" v-model="email"
                                class="rounded-4 p-3 mt-2 w-100" style="border-color: white;" />
                            <label class="form-label" for="form3Example3c"></label>
                        </div>
                    </div>
                    <!-- ŞİFRE -->
                    <div class="d-flex align-items-center mb-4">
                        <i class="bi bi-lock fa-lg me-3 fa-fw"></i>
                        <div class="form-outline  mb-0">
                            <input required placeholder="Şifre" id="form3Example4c" v-model="password"
                                class="rounded-4 p-3 pl-3 mt-2 w-100" style="border-color: white;"
                                :type="showPassword ? 'text' : 'password'" />
                            <label class="form-label" for="form3Example4c"></label>
                            <!-- Göz ikonunu buraya ekledik -->
                            <i class="bi position-absolute" :class="showPassword ? 'bi-eye' : 'bi-eye-slash'"
                                @click="togglePasswordVisibility"
                                style="cursor: pointer; top: 50%; transform: translateY(-50%); right: 15px;"></i>
                        </div>
                    </div>
                    <div class="d-grid gap-2 mt-5">
                        <Button class="rounded-2" type="submit" label="Giriş" severity="success" id="submit-btn"></Button>
                    </div><br><br>
                    <div><router-link style="text-decoration: none; " to="parola-sifirlama"><b>Şifremi
                                Unuttum</b></router-link></div><br>
                    <p class="mesaj">Üye olmak için <router-link style="text-decoration: none; " to="kayit"><b>Kayıt
                                Ol</b></router-link></p>
                    <div class="text-center">

                        <p>Veya</p>
                        <!-- Google'a yönlendiren <a> etiketi -->
                        <a href="https://accounts.google.com/InteractiveLogin/identifier?continue=https%3A%2F%2Fwww.google.com.tr%2F%3Fhl%3Dtr&ec=GAZAmgQ&hl=tr&passive=true&ifkv=AeDOFXgZH2f9aVeBhHPppyO5xzGIHs6rddx8R-06Sp0q15OGJBiqgkT6YcKDAfcNyqjI-byv6QNBww&flowName=GlifWebSignIn&flowEntry=ServiceLogin"
                            target="_blank" class="btn btn-secondary btn-floating mx-1">
                            <i class="fab fa-google"></i>
                        </a>
                        <!-- Github'a yönlendiren <a> etiketi -->
                        <a href="https://www.github.com" target="_blank" class="btn btn-secondary btn-floating mx-1">
                            <i class="fab fa-github"></i>
                        </a>
                        <!-- Twitter'a yönlendiren <a> etiketi -->
                        <a href="https://www.twitter.com" target="_blank" class="btn btn-secondary btn-floating mx-1">
                            <i class="fab fa-twitter"></i>
                        </a>
                    </div>
                </form>

            </div>

        </div>
    </div>
    <div v-else>
        <div class="position-absolute top-50 start-50 translate-middle w-50" style="max-height: 10%;">
            <img src="../assets/preloader.gif" height="95" width="95">
            <!-- <i class="pi pi-spin pi-cog" style="font-size: 2rem"></i> -->
        </div>


    </div>
</template>


<script>
import { ref } from "vue";
import { getAuth, signInWithEmailAndPassword } from 'firebase/auth'
import firebaseConfig from '@/firebase/firebaseInit';

const checked = ref(false);

//GÖZ İKONU ÇALIŞSIN DİYE
const showPassword = ref(false);

const togglePasswordVisibility = () => {
    showPassword.value = !showPassword.value;
};

export default {
    data() {
        return {
            isAuthenticated: '',
            email: '',
            password: '',
            isLoading: false,
        };
    },
    methods: {
        login() {
            this.isLoading = true;
            const auth = getAuth()
            signInWithEmailAndPassword(auth, this.email, this.password)
                .then((result) => {
                    const user = result.user;
                    firebaseConfig.currentUser = user;
                    console.log(user.email, user.displayName);
                    this.isLoading = false;
                    this.$router.push({ name: 'gib' });
                })
                .catch((error) => {
                    const errorCode = error.code;
                    const errorMessage = error.message;
                    //setMode("INCORRECT");
                    this.isLoading = false;
                    this.showError('Yanlış Email veya Şifre')
                    console.log(errorCode, errorMessage);
                });

            const formData = {
                "email": this.email,
                "password": this.password
            };

            console.log("Form Data : " + JSON.stringify(formData));

            /*
            {
            "uid": "ykfurkan",
            "tenantId": null,
            "email": "furkan.misirli@yurticikargo.com",
            "phoneNumber": null,
            "emailVerified": true,
            "displayName": "Furkanmısırlı",
            "photoUrl": null,
            "disabled": false,
            "tokensValidAfterTimestamp": 1688544036000,
            "userMetadata": {
                "creationTimestamp": 1688544036328,
                "lastSignInTimestamp": 0,
                "lastRefreshTimestamp": 0
            },
            "customClaims": {},
            "providerData": [
                {
                "uid": "furkan.misirli@yurticikargo.com",
                "displayName": "Furkanmısırlı",
                "email": "furkan.misirli@yurticikargo.com",
                "phoneNumber": null,
                "photoUrl": null,
                "providerId": "password"
                }
            ],
            "providerId": "firebase"
            }
            */
        },


    },

    created() {
        const token = localStorage.getItem('token');
        if (token) {
            this.isAuthenticated = true;
        }
    }
};
</script>

<script setup>
import { useToast } from "primevue/usetoast";

import { inject } from 'vue';
import { getAuth } from 'firebase/auth'
const apiUrl = inject('apiUrl');

const toast = useToast();

const showSuccess = (message) => {
    toast.add({ severity: 'success', summary: 'Başarılı', detail: message, life: 3000 });
};

const showInfo = (message) => {
    toast.add({ severity: 'info', summary: 'Bilgi', detail: message, life: 3000 });
};

const showWarn = (message) => {
    toast.add({ severity: 'warn', summary: 'Uyarı', detail: message, life: 3000 });
};

const showError = (message) => {
    toast.add({ severity: 'error', summary: 'Hata', detail: message, life: 3000 });
};
</script>

<style>
#submit-btn {
    height: 45px;
}

.user-info {
    background-color: rgba(231, 226, 226, 0.737);
    box-shadow: 3px 7px 13px 6px #888888;
    height: 450px;
    align-items: center;
    flex-direction: column;
}

.login-part {
    display: flex;
    flex-direction: column;
    align-items: center;
    font-family: var(--italic);
    background-color: rgba(237, 236, 236, 0.851);
    margin-top: 50px;
}

.form-outline {
    position: relative;
}

form div {
    margin: 15px;
}

.login-form {
    display: flex;
    flex-direction: column;
    align-items: center;
}

.form label {
    width: 120px;
}

button {
    color: p-button-primary;
    background-color: p-button-primary;
}


.vertical-line {
    border-left: 0.5px solid black;
    height: 600px;
    /* Çizginin yüksekliğini istediğiniz değere ayarlayın */
    margin: 0 auto;
}

@media only screen and (max-width: 600px) {
    body {
        background-color: lightblue;
    }

    .login-part img {
        display: none;
    }
}
</style>
